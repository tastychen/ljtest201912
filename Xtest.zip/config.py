dbinfo = {
    "host":"192.144.148.91",
    "user":"ljtest",
    "password":"123456",
    "dbname":"ljtestdb"
}
host = "http://192.144.148.91:2333"

exclename = "./data/接口测试用例.xlsx"
sheetname = "Cases"